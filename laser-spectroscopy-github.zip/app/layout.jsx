import './globals.css'

export const metadata = {
  title: 'منصة الطيفية الليزرية',
  description: 'مقرر الطيفية الليزرية — معهد الليزر للدراسات العليا، جامعة بغداد',
}

export default function RootLayout({ children }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  )
}
