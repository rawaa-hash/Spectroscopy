'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

export default function LoginPage() {
  const router = useRouter()
  const supabase = createClient()

  const [mode, setMode] = useState('in')      // in | up
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [fullName, setFullName] = useState('')
  const [studentId, setStudentId] = useState('')
  const [err, setErr] = useState('')
  const [ok, setOk] = useState('')
  const [busy, setBusy] = useState(false)

  async function submit(e) {
    e.preventDefault()
    setErr(''); setOk(''); setBusy(true)

    if (mode === 'in') {
      const { error } = await supabase.auth.signInWithPassword({ email, password })
      if (error) { setErr(translate(error.message)); setBusy(false); return }
      router.push('/dashboard')
      router.refresh()
    } else {
      if (!fullName.trim()) { setErr('اكتب الاسم الثلاثي.'); setBusy(false); return }
      const { data, error } = await supabase.auth.signUp({
        email, password,
        options: { data: { full_name: fullName, student_id: studentId } },
      })
      if (error) { setErr(translate(error.message)); setBusy(false); return }
      if (data.session) { router.push('/dashboard'); router.refresh(); return }
      setOk('تم إنشاء الحساب. افحص بريدك لتأكيد التسجيل ثم سجّل الدخول.')
      setBusy(false)
    }
  }

  return (
    <div className="auth">
      <div style={{ textAlign: 'center', marginBottom: 22 }}>
        <h1 style={{ fontSize: 20, margin: '0 0 4px' }}>منصة الطيفية الليزرية</h1>
        <p className="muted small" style={{ margin: 0 }}>
          معهد الليزر للدراسات العليا — جامعة بغداد
        </p>
      </div>

      <div className="card">
        <div className="tabs2">
          <button className={mode === 'in' ? 'on' : ''} onClick={() => { setMode('in'); setErr(''); setOk('') }}>
            تسجيل الدخول
          </button>
          <button className={mode === 'up' ? 'on' : ''} onClick={() => { setMode('up'); setErr(''); setOk('') }}>
            حساب جديد
          </button>
        </div>

        {err && <div className="msg err">{err}</div>}
        {ok && <div className="msg ok">{ok}</div>}

        <form onSubmit={submit}>
          {mode === 'up' && (
            <>
              <div className="field">
                <label htmlFor="fn">الاسم الثلاثي</label>
                <input id="fn" value={fullName} onChange={e => setFullName(e.target.value)} required />
              </div>
              <div className="field">
                <label htmlFor="sid">الرقم الجامعي (اختياري)</label>
                <input id="sid" value={studentId} onChange={e => setStudentId(e.target.value)} />
              </div>
            </>
          )}

          <div className="field">
            <label htmlFor="em">البريد الإلكتروني</label>
            <input id="em" type="email" value={email} onChange={e => setEmail(e.target.value)} required />
          </div>

          <div className="field">
            <label htmlFor="pw">كلمة المرور</label>
            <input id="pw" type="password" value={password} onChange={e => setPassword(e.target.value)}
                   required minLength={6} />
          </div>

          <button className="btn primary" style={{ width: '100%' }} disabled={busy}>
            {busy ? 'جارٍ...' : mode === 'in' ? 'دخول' : 'إنشاء الحساب'}
          </button>
        </form>
      </div>

      <p className="muted small" style={{ textAlign: 'center' }}>
        كل الحسابات الجديدة تُنشأ كطلبة. لترقية حساب إلى تدريسي، غيّري الحقل role في جدول profiles من لوحة Supabase.
      </p>
    </div>
  )
}

function translate(m) {
  if (/Invalid login credentials/i.test(m)) return 'البريد أو كلمة المرور غير صحيحة.'
  if (/already registered/i.test(m)) return 'هذا البريد مسجَّل مسبقاً.'
  if (/Password should be/i.test(m)) return 'كلمة المرور قصيرة — ٦ خانات على الأقل.'
  if (/Email not confirmed/i.test(m)) return 'لم يتم تأكيد البريد بعد. افحص رسالة التأكيد.'
  return m
}
