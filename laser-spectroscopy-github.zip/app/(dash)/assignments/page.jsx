import Link from 'next/link'
import { getUserProfile } from '@/lib/supabase/server'
import { fmtDate, KIND_AR } from '@/lib/course'

export const dynamic = 'force-dynamic'

export default async function Assignments() {
  const { user, profile, supabase } = await getUserProfile()
  const isInstructor = profile?.role === 'instructor'

  const { data: assignments } = await supabase
    .from('assignments')
    .select('*')
    .order('week', { ascending: true, nullsFirst: false })

  const { data: subs } = await supabase
    .from('submissions')
    .select('assignment_id, student_id, score')

  return (
    <>
      <h2 className="sec">الواجبات وتقارير المختبر</h2>

      {(!assignments || assignments.length === 0) && (
        <div className="card muted">لا توجد واجبات منشورة بعد.</div>
      )}

      {(assignments || []).map(a => {
        const mine = (subs || []).find(s => s.assignment_id === a.id && s.student_id === user.id)
        const count = (subs || []).filter(s => s.assignment_id === a.id).length
        const late = a.due_at && new Date(a.due_at) < new Date()

        return (
          <div className="card" key={a.id}>
            <div className="row" style={{ justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div style={{ flex: 1, minWidth: 200 }}>
                <h3>{a.title}</h3>
                <p className="muted small" style={{ margin: '0 0 8px' }}>
                  {KIND_AR[a.kind]} · الأسبوع {a.week || '—'} · من {a.max_score} درجات · آخر موعد: {fmtDate(a.due_at)}
                </p>
                {a.description && <p className="small" style={{ margin: 0 }}>{a.description}</p>}
                <div className="row" style={{ marginTop: 10 }}>
                  {!a.is_open && <span className="pill">مغلق</span>}
                  {late && a.is_open && <span className="pill late">انتهى الموعد</span>}
                  {isInstructor
                    ? <span className="pill">{count} تسليم</span>
                    : mine
                      ? (mine.score !== null
                          ? <span className="pill ok">مصحَّح: {mine.score}/{a.max_score}</span>
                          : <span className="pill warn">مُسلَّم — بانتظار التصحيح</span>)
                      : <span className="pill late">لم يُسلَّم</span>}
                </div>
              </div>
              <Link
                className="btn primary"
                href={isInstructor ? `/teacher/${a.id}` : `/assignments/${a.id}`}
              >
                {isInstructor ? 'التسليمات' : mine ? 'التفاصيل' : 'رفع التقرير'}
              </Link>
            </div>
          </div>
        )
      })}
    </>
  )
}
