import Link from 'next/link'
import { notFound } from 'next/navigation'
import { getUserProfile } from '@/lib/supabase/server'
import { fmtDate, KIND_AR } from '@/lib/course'
import SubmitForm from '@/components/SubmitForm'

export const dynamic = 'force-dynamic'

export default async function AssignmentPage({ params }) {
  const { id } = await params
  const { user, supabase } = await getUserProfile()

  const { data: a } = await supabase.from('assignments').select('*').eq('id', id).single()
  if (!a) notFound()

  const { data: sub } = await supabase
    .from('submissions')
    .select('*')
    .eq('assignment_id', id)
    .eq('student_id', user.id)
    .maybeSingle()

  let fileUrl = null
  if (sub) {
    const { data } = await supabase.storage.from('reports').createSignedUrl(sub.file_path, 3600)
    fileUrl = data?.signedUrl || null
  }

  return (
    <>
      <p style={{ margin: '18px 0 0' }}><Link href="/assignments">← كل الواجبات</Link></p>

      <h2 className="sec">{a.title}</h2>
      <div className="card">
        <p className="muted small" style={{ margin: '0 0 10px' }}>
          {KIND_AR[a.kind]} · الأسبوع {a.week || '—'} · الدرجة القصوى {a.max_score} · آخر موعد: {fmtDate(a.due_at)}
        </p>
        {a.description && <p style={{ margin: 0 }}>{a.description}</p>}
      </div>

      {sub && (
        <div className="card">
          <h3>تسليمك الحالي</h3>
          <p className="small" style={{ margin: '0 0 6px' }}>
            {fileUrl
              ? <a href={fileUrl} target="_blank" rel="noreferrer">{sub.file_name}</a>
              : sub.file_name}
            <span className="muted"> · {fmtDate(sub.submitted_at)}</span>
          </p>
          {sub.note && <p className="small muted" style={{ margin: '0 0 10px' }}>ملاحظتك: {sub.note}</p>}

          {sub.score !== null ? (
            <>
              <p style={{ margin: '10px 0 4px' }}>
                <span className="pill ok">الدرجة: {sub.score} / {a.max_score}</span>
              </p>
              {sub.feedback && (
                <p className="small" style={{ margin: '8px 0 0' }}>
                  <b>ملاحظات التدريسي:</b> {sub.feedback}
                </p>
              )}
            </>
          ) : (
            <span className="pill warn">بانتظار التصحيح</span>
          )}
        </div>
      )}

      <div className="card">
        <h3>{sub ? 'استبدال التقرير' : 'رفع التقرير'}</h3>
        {sub && sub.score !== null ? (
          <p className="muted small" style={{ margin: 0 }}>
            تم تصحيح تقريرك، ولا يمكن استبداله. راجعي التدريسي إذا احتجت إعادة التسليم.
          </p>
        ) : (
          <SubmitForm assignmentId={a.id} disabled={!a.is_open} />
        )}
      </div>
    </>
  )
}
