import { getUserProfile } from '@/lib/supabase/server'
import { fmtDate } from '@/lib/course'

export const dynamic = 'force-dynamic'

export default async function Grades() {
  const { user, profile, supabase } = await getUserProfile()
  const isInstructor = profile?.role === 'instructor'

  const { data: assignments } = await supabase
    .from('assignments')
    .select('*')
    .order('week', { ascending: true, nullsFirst: false })

  const { data: subs } = await supabase.from('submissions').select('*')

  if (!isInstructor) {
    const mine = (subs || []).filter(s => s.student_id === user.id)
    const rows = (assignments || []).map(a => ({
      a, s: mine.find(x => x.assignment_id === a.id),
    }))
    const got = rows.filter(r => r.s?.score !== null && r.s !== undefined)
    const total = got.reduce((x, r) => x + Number(r.s.score), 0)
    const outOf = got.reduce((x, r) => x + Number(r.a.max_score), 0)

    return (
      <>
        <h2 className="sec">درجاتي</h2>
        <div className="card">
          <table>
            <thead><tr><th>الواجب</th><th>الحالة</th><th>الدرجة</th><th>ملاحظات</th></tr></thead>
            <tbody>
              {rows.map(({ a, s }) => (
                <tr key={a.id}>
                  <td>{a.title}</td>
                  <td className="small">
                    {!s ? <span className="pill late">لم يُسلَّم</span>
                      : s.score === null ? <span className="pill warn">بانتظار التصحيح</span>
                      : <span className="pill ok">مصحَّح</span>}
                  </td>
                  <td className="m">{s?.score ?? '—'} / {a.max_score}</td>
                  <td className="small muted">{s?.feedback || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <p style={{ marginBottom: 0, marginTop: 14 }}>
            <span className="pill ok">المجموع المصحَّح: {total} / {outOf || 0}</span>
          </p>
        </div>
      </>
    )
  }

  // عرض التدريسي: سجل درجات لكل الطلبة
  const { data: students } = await supabase
    .from('profiles')
    .select('*')
    .eq('role', 'student')
    .order('full_name')

  return (
    <>
      <h2 className="sec">سجل الدرجات</h2>
      <div className="card" style={{ overflowX: 'auto' }}>
        <table>
          <thead>
            <tr>
              <th>الطالب</th>
              {(assignments || []).map(a => (
                <th key={a.id} style={{ minWidth: 90 }}>{a.title.slice(0, 18)}</th>
              ))}
              <th>المجموع</th>
            </tr>
          </thead>
          <tbody>
            {(students || []).map(st => {
              let tot = 0
              return (
                <tr key={st.id}>
                  <td>
                    {st.full_name || '—'}
                    {st.student_id && <span className="muted small"> · {st.student_id}</span>}
                  </td>
                  {(assignments || []).map(a => {
                    const s = (subs || []).find(x => x.assignment_id === a.id && x.student_id === st.id)
                    if (s?.score !== null && s !== undefined) tot += Number(s.score)
                    return (
                      <td className="m small" key={a.id}>
                        {!s ? '—' : s.score === null ? '⏳' : s.score}
                      </td>
                    )
                  })}
                  <td className="m">{tot}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
        {(!students || students.length === 0) && (
          <p className="muted small" style={{ marginBottom: 0 }}>لا يوجد طلبة مسجَّلون بعد.</p>
        )}
      </div>
      <p className="muted small">⏳ يعني مُسلَّم وينتظر التصحيح، و — يعني لم يُسلَّم.</p>
    </>
  )
}
