import Link from 'next/link'
import { getUserProfile } from '@/lib/supabase/server'
import { fmtDate, KIND_AR } from '@/lib/course'

export const dynamic = 'force-dynamic'

export default async function Dashboard() {
  const { user, profile, supabase } = await getUserProfile()
  const isInstructor = profile?.role === 'instructor'

  const { data: assignments } = await supabase
    .from('assignments')
    .select('*')
    .order('week', { ascending: true })

  const { data: subs } = await supabase.from('submissions').select('*')

  const mine = (subs || []).filter(s => s.student_id === user.id)
  const graded = mine.filter(s => s.score !== null)
  const total = graded.reduce((a, s) => a + Number(s.score), 0)
  const outOf = graded.reduce((a, s) => {
    const asg = (assignments || []).find(x => x.id === s.assignment_id)
    return a + Number(asg?.max_score || 0)
  }, 0)

  const openOnes = (assignments || []).filter(a => a.is_open)
  const pending = openOnes.filter(a => !mine.some(s => s.assignment_id === a.id))

  return (
    <>
      <h2 className="sec">أهلاً {profile?.full_name || ''}</h2>

      {isInstructor ? (
        <div className="grid">
          <div className="stat"><b>{assignments?.length || 0}</b><span>واجب منشور</span></div>
          <div className="stat"><b>{subs?.length || 0}</b><span>تسليم مستلم</span></div>
          <div className="stat"><b>{(subs || []).filter(s => s.score === null).length}</b><span>بانتظار التصحيح</span></div>
        </div>
      ) : (
        <div className="grid">
          <div className="stat"><b>{mine.length}</b><span>تقرير مرفوع</span></div>
          <div className="stat"><b>{pending.length}</b><span>واجب لم يُسلَّم</span></div>
          <div className="stat">
            <b>{outOf ? `${total}/${outOf}` : '—'}</b><span>مجموع الدرجات المصححة</span>
          </div>
        </div>
      )}

      <h2 className="sec">{isInstructor ? 'آخر التسليمات' : 'واجبات مفتوحة'}</h2>

      {isInstructor ? (
        (subs || []).length === 0 ? (
          <div className="card muted">لا توجد تسليمات بعد.</div>
        ) : (
          <div className="card">
            <table>
              <thead><tr><th>الواجب</th><th>وقت التسليم</th><th>الحالة</th></tr></thead>
              <tbody>
                {[...subs]
                  .sort((a, b) => new Date(b.submitted_at) - new Date(a.submitted_at))
                  .slice(0, 8)
                  .map(s => {
                    const a = (assignments || []).find(x => x.id === s.assignment_id)
                    return (
                      <tr key={s.id}>
                        <td><Link href={`/teacher/${s.assignment_id}`}>{a?.title || '—'}</Link></td>
                        <td className="m small">{fmtDate(s.submitted_at)}</td>
                        <td>
                          {s.score === null
                            ? <span className="pill warn">بانتظار التصحيح</span>
                            : <span className="pill ok">{s.score}</span>}
                        </td>
                      </tr>
                    )
                  })}
              </tbody>
            </table>
          </div>
        )
      ) : pending.length === 0 ? (
        <div className="card muted">لا توجد واجبات معلّقة. عمل ممتاز.</div>
      ) : (
        pending.map(a => (
          <div className="card" key={a.id}>
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <div>
                <h3>{a.title}</h3>
                <p className="muted small" style={{ margin: 0 }}>
                  {KIND_AR[a.kind]} · الأسبوع {a.week || '—'} · آخر موعد: {fmtDate(a.due_at)}
                </p>
              </div>
              <Link className="btn primary" href={`/assignments/${a.id}`}>رفع التقرير</Link>
            </div>
          </div>
        ))
      )}
    </>
  )
}
