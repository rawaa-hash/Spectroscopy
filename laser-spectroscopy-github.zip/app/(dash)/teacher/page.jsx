import Link from 'next/link'
import { redirect } from 'next/navigation'
import { getUserProfile } from '@/lib/supabase/server'
import { fmtDate, KIND_AR } from '@/lib/course'
import NewAssignment from '@/components/NewAssignment'
import { toggleAssignment } from '@/app/actions'

export const dynamic = 'force-dynamic'

export default async function Teacher() {
  const { profile, supabase } = await getUserProfile()
  if (profile?.role !== 'instructor') redirect('/dashboard')

  const { data: assignments } = await supabase
    .from('assignments')
    .select('*')
    .order('week', { ascending: true, nullsFirst: false })

  const { data: subs } = await supabase.from('submissions').select('assignment_id, score')

  return (
    <>
      <h2 className="sec">إدارة الواجبات</h2>
      <NewAssignment />

      {(assignments || []).map(a => {
        const all = (subs || []).filter(s => s.assignment_id === a.id)
        const ungraded = all.filter(s => s.score === null).length

        return (
          <div className="card" key={a.id}>
            <div className="row" style={{ justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div style={{ flex: 1, minWidth: 200 }}>
                <h3>{a.title}</h3>
                <p className="muted small" style={{ margin: '0 0 8px' }}>
                  {KIND_AR[a.kind]} · الأسبوع {a.week || '—'} · من {a.max_score} · آخر موعد: {fmtDate(a.due_at)}
                </p>
                <div className="row">
                  <span className="pill">{all.length} تسليم</span>
                  {ungraded > 0 && <span className="pill warn">{ungraded} بانتظار التصحيح</span>}
                  {!a.is_open && <span className="pill">مغلق</span>}
                </div>
              </div>
              <div className="row">
                <form action={toggleAssignment}>
                  <input type="hidden" name="id" value={a.id} />
                  <input type="hidden" name="is_open" value={String(a.is_open)} />
                  <button className="btn">{a.is_open ? 'غلق التسليم' : 'فتح التسليم'}</button>
                </form>
                <Link className="btn primary" href={`/teacher/${a.id}`}>تصحيح</Link>
              </div>
            </div>
          </div>
        )
      })}
    </>
  )
}
