import Link from 'next/link'
import { notFound, redirect } from 'next/navigation'
import { getUserProfile } from '@/lib/supabase/server'
import { fmtDate, KIND_AR } from '@/lib/course'
import GradeForm from '@/components/GradeForm'

export const dynamic = 'force-dynamic'

export default async function GradeAssignment({ params }) {
  const { id } = await params
  const { profile, supabase } = await getUserProfile()
  if (profile?.role !== 'instructor') redirect('/dashboard')

  const { data: a } = await supabase.from('assignments').select('*').eq('id', id).single()
  if (!a) notFound()

  const { data: subs } = await supabase
    .from('submissions')
    .select('*, profiles!submissions_student_id_fkey(full_name, student_id)')
    .eq('assignment_id', id)
    .order('submitted_at', { ascending: false })

  const withUrls = await Promise.all(
    (subs || []).map(async s => {
      const { data } = await supabase.storage.from('reports').createSignedUrl(s.file_path, 3600)
      return { ...s, url: data?.signedUrl || null }
    })
  )

  return (
    <>
      <p style={{ margin: '18px 0 0' }}><Link href="/teacher">← إدارة الواجبات</Link></p>

      <h2 className="sec">{a.title}</h2>
      <p className="muted small">
        {KIND_AR[a.kind]} · الأسبوع {a.week || '—'} · من {a.max_score} درجات · {withUrls.length} تسليم
      </p>

      {withUrls.length === 0 && <div className="card muted">لا توجد تسليمات لهذا الواجب بعد.</div>}

      {withUrls.map(s => (
        <div className="card" key={s.id}>
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <h3 style={{ margin: 0 }}>
              {s.profiles?.full_name || 'طالب'}
              {s.profiles?.student_id && <span className="muted small"> · {s.profiles.student_id}</span>}
            </h3>
            {s.score === null
              ? <span className="pill warn">بانتظار التصحيح</span>
              : <span className="pill ok">{s.score} / {a.max_score}</span>}
          </div>

          <p className="small" style={{ margin: '10px 0 0' }}>
            {s.url ? <a href={s.url} target="_blank" rel="noreferrer">تحميل: {s.file_name}</a> : s.file_name}
            <span className="muted"> · {fmtDate(s.submitted_at)}</span>
            {a.due_at && new Date(s.submitted_at) > new Date(a.due_at) &&
              <span className="pill late" style={{ marginInlineStart: 8 }}>متأخر</span>}
          </p>

          {s.note && <p className="small muted" style={{ margin: '6px 0 0' }}>ملاحظة الطالب: {s.note}</p>}

          <GradeForm submissionId={s.id} score={s.score} feedback={s.feedback} max={a.max_score} />
        </div>
      ))}
    </>
  )
}
