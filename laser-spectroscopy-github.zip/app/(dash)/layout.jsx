import { redirect } from 'next/navigation'
import { getUserProfile } from '@/lib/supabase/server'
import NavBar from '@/components/NavBar'

export default async function DashLayout({ children }) {
  const { user, profile } = await getUserProfile()
  if (!user) redirect('/login')

  return (
    <>
      <NavBar name={profile?.full_name || user.email} role={profile?.role} />
      <div className="wrap">{children}</div>
      <footer>مقرر الطيفية الليزرية — ماجستير — ٣ وحدات — أ.م.د. رواء أحمد فارس</footer>
    </>
  )
}
