import { WEEKS } from '@/lib/course'

export default function CoursePage() {
  return (
    <>
      <h2 className="sec">مفردات المقرر</h2>
      <p className="muted small">
        خمسة عشر أسبوعاً نظرياً بواقع ساعتين أسبوعياً، مع ٤٥ ساعة مختبر موزّعة على ١٥ جلسة.
      </p>

      {WEEKS.map(w => (
        <details className="week" key={w.n}>
          <summary>
            <span className="num">{w.n}</span>
            <span>
              {w.ar}
              <span className="muted small ltr" style={{ display: 'block', fontWeight: 400 }}>{w.en}</span>
            </span>
          </summary>
          <div className="body">
            <h3 style={{ fontSize: 13, color: 'var(--muted)', margin: '14px 0 7px' }}>المفردات</h3>
            <ul className="t ltr">{w.topics.map((t, i) => <li key={i}>{t}</li>)}</ul>
            <h3 style={{ fontSize: 13, color: 'var(--muted)', margin: '14px 0 7px' }}>المعادلات الأساسية</h3>
            {w.eq.map((e, i) => <div className="eq" key={i}>{e}</div>)}
          </div>
        </details>
      ))}
    </>
  )
}
