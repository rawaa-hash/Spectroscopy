'use server'

import { revalidatePath } from 'next/cache'
import { createClient } from '@/lib/supabase/server'

function safeName(name) {
  const dot = name.lastIndexOf('.')
  const ext = dot > -1 ? name.slice(dot).toLowerCase() : ''
  const base = (dot > -1 ? name.slice(0, dot) : name)
    .replace(/[^A-Za-z0-9._-]/g, '_')
    .slice(0, 40) || 'report'
  return base + ext
}

/* ---------- الطالب: رفع تقرير ---------- */
export async function submitReport(prevState, formData) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { error: 'انتهت الجلسة. سجّل الدخول من جديد.' }

  const assignmentId = formData.get('assignment_id')
  const note = (formData.get('note') || '').toString().slice(0, 1000)
  const file = formData.get('file')

  if (!file || typeof file === 'string' || file.size === 0) {
    return { error: 'اختر ملف التقرير أولاً.' }
  }
  if (file.size > 20 * 1024 * 1024) {
    return { error: 'حجم الملف أكبر من ٢٠ ميغابايت.' }
  }

  const path = `${user.id}/${assignmentId}/${Date.now()}-${safeName(file.name)}`

  const { error: upErr } = await supabase.storage
    .from('reports')
    .upload(path, file, { contentType: file.type || 'application/octet-stream' })

  if (upErr) return { error: 'تعذّر رفع الملف: ' + upErr.message }

  const { error: dbErr } = await supabase
    .from('submissions')
    .upsert(
      {
        assignment_id: assignmentId,
        student_id: user.id,
        file_path: path,
        file_name: file.name,
        note,
        submitted_at: new Date().toISOString(),
      },
      { onConflict: 'assignment_id,student_id' }
    )

  if (dbErr) {
    await supabase.storage.from('reports').remove([path])
    return { error: 'تعذّر حفظ التسليم. إن كان تقريرك مصحَّحاً فلا يمكن استبداله.' }
  }

  revalidatePath('/assignments')
  revalidatePath(`/assignments/${assignmentId}`)
  revalidatePath('/grades')
  revalidatePath('/dashboard')
  return { ok: 'تم رفع التقرير بنجاح.' }
}

/* ---------- التدريسي: تصحيح تسليم ---------- */
export async function gradeSubmission(prevState, formData) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { error: 'انتهت الجلسة.' }

  const id = formData.get('submission_id')
  const raw = formData.get('score')
  const score = raw === '' || raw === null ? null : Number(raw)
  const feedback = (formData.get('feedback') || '').toString().slice(0, 2000)

  if (score !== null && (Number.isNaN(score) || score < 0)) {
    return { error: 'الدرجة غير صحيحة.' }
  }

  const { error } = await supabase
    .from('submissions')
    .update({
      score,
      feedback,
      graded_at: score === null ? null : new Date().toISOString(),
      graded_by: user.id,
    })
    .eq('id', id)

  if (error) return { error: 'تعذّر حفظ الدرجة: ' + error.message }

  revalidatePath('/teacher')
  revalidatePath('/grades')
  return { ok: 'حُفظت الدرجة.' }
}

/* ---------- التدريسي: إنشاء واجب ---------- */
export async function createAssignment(prevState, formData) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { error: 'انتهت الجلسة.' }

  const title = (formData.get('title') || '').toString().trim()
  if (!title) return { error: 'اكتب عنوان الواجب.' }

  const weekRaw = formData.get('week')
  const dueRaw = formData.get('due_at')

  const { error } = await supabase.from('assignments').insert({
    title,
    description: (formData.get('description') || '').toString(),
    kind: formData.get('kind') || 'lab',
    week: weekRaw ? Number(weekRaw) : null,
    max_score: Number(formData.get('max_score') || 10),
    due_at: dueRaw ? new Date(dueRaw).toISOString() : null,
    created_by: user.id,
  })

  if (error) return { error: 'تعذّر إنشاء الواجب: ' + error.message }

  revalidatePath('/teacher')
  revalidatePath('/assignments')
  return { ok: 'أُضيف الواجب.' }
}

/* ---------- التدريسي: فتح/غلق واجب ---------- */
export async function toggleAssignment(formData) {
  const supabase = await createClient()
  const id = formData.get('id')
  const open = formData.get('is_open') === 'true'
  await supabase.from('assignments').update({ is_open: !open }).eq('id', id)
  revalidatePath('/teacher')
  revalidatePath('/assignments')
}
