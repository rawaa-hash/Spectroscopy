-- =====================================================================
--  منصة الطيفية الليزرية — مخطط قاعدة البيانات
--  معهد الليزر للدراسات العليا / جامعة بغداد
--  نفّذ هذا الملف كاملاً مرة واحدة في:  Supabase > SQL Editor > New query
-- =====================================================================

-- ------------------------- 1) الملفات الشخصية -------------------------
create table if not exists public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text not null default '',
  student_id  text default '',
  role        text not null default 'student' check (role in ('student','instructor')),
  created_at  timestamptz not null default now()
);

-- إنشاء الملف الشخصي تلقائياً عند تسجيل مستخدم جديد
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, student_id)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', ''),
    coalesce(new.raw_user_meta_data->>'student_id', '')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- دالة مساعدة: هل المستخدم الحالي تدريسي؟
-- security definer حتى لا تتكرر سياسات RLS على جدول profiles
create or replace function public.is_instructor()
returns boolean
language sql
stable
security definer set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'instructor'
  );
$$;

-- ------------------------- 2) الواجبات -------------------------------
create table if not exists public.assignments (
  id          uuid primary key default gen_random_uuid(),
  title       text not null,
  description text default '',
  kind        text not null default 'lab' check (kind in ('lab','homework','project','seminar')),
  week        int  check (week between 1 and 15),
  max_score   numeric not null default 10,
  due_at      timestamptz,
  is_open     boolean not null default true,
  created_by  uuid references public.profiles(id) on delete set null,
  created_at  timestamptz not null default now()
);

-- ------------------------- 3) التسليمات -----------------------------
create table if not exists public.submissions (
  id            uuid primary key default gen_random_uuid(),
  assignment_id uuid not null references public.assignments(id) on delete cascade,
  student_id    uuid not null references public.profiles(id) on delete cascade,
  file_path     text not null,
  file_name     text not null,
  note          text default '',
  submitted_at  timestamptz not null default now(),
  score         numeric,
  feedback      text,
  graded_at     timestamptz,
  graded_by     uuid references public.profiles(id) on delete set null,
  unique (assignment_id, student_id)
);

create index if not exists submissions_assignment_idx on public.submissions(assignment_id);
create index if not exists submissions_student_idx    on public.submissions(student_id);

-- ------------------------- 4) سياسات RLS ------------------------------
alter table public.profiles    enable row level security;
alter table public.assignments enable row level security;
alter table public.submissions enable row level security;

-- profiles
drop policy if exists profiles_select_self on public.profiles;
create policy profiles_select_self on public.profiles
  for select using (id = auth.uid() or public.is_instructor());

drop policy if exists profiles_update_self on public.profiles;
create policy profiles_update_self on public.profiles
  for update using (id = auth.uid()) with check (id = auth.uid());

-- assignments: يقرأها الجميع، ويديرها التدريسي فقط
drop policy if exists assignments_select_all on public.assignments;
create policy assignments_select_all on public.assignments
  for select to authenticated using (true);

drop policy if exists assignments_write_instructor on public.assignments;
create policy assignments_write_instructor on public.assignments
  for all to authenticated
  using (public.is_instructor())
  with check (public.is_instructor());

-- submissions: الطالب يرى ويرفع تسليمه فقط، والتدريسي يرى الكل ويصحّح
drop policy if exists submissions_select on public.submissions;
create policy submissions_select on public.submissions
  for select to authenticated
  using (student_id = auth.uid() or public.is_instructor());

drop policy if exists submissions_insert_own on public.submissions;
create policy submissions_insert_own on public.submissions
  for insert to authenticated
  with check (student_id = auth.uid());

drop policy if exists submissions_update_own on public.submissions;
create policy submissions_update_own on public.submissions
  for update to authenticated
  using (student_id = auth.uid() and score is null)
  with check (student_id = auth.uid() and score is null);

drop policy if exists submissions_update_instructor on public.submissions;
create policy submissions_update_instructor on public.submissions
  for update to authenticated
  using (public.is_instructor())
  with check (public.is_instructor());

drop policy if exists submissions_delete_instructor on public.submissions;
create policy submissions_delete_instructor on public.submissions
  for delete to authenticated using (public.is_instructor());

-- ------------------------- 5) التخزين (ملفات التقارير) ----------------
insert into storage.buckets (id, name, public)
values ('reports', 'reports', false)
on conflict (id) do nothing;

-- مسار الملف يبدأ دائماً بمعرّف الطالب:  {user_id}/اسم_الملف
drop policy if exists reports_insert_own on storage.objects;
create policy reports_insert_own on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'reports'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

drop policy if exists reports_select on storage.objects;
create policy reports_select on storage.objects
  for select to authenticated
  using (
    bucket_id = 'reports'
    and ((storage.foldername(name))[1] = auth.uid()::text or public.is_instructor())
  );

drop policy if exists reports_update_own on storage.objects;
create policy reports_update_own on storage.objects
  for update to authenticated
  using (
    bucket_id = 'reports'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

-- ------------------------- 6) بيانات أولية (اختياري) -------------------
-- واجبات المختبر الخمسة عشر. نفّذها بعد إنشاء حسابك كتدريسي إن أردت.
insert into public.assignments (title, kind, week, max_score, description)
values
 ('تقرير المختبر ١ — السلامة والأجهزة الطيفية', 'lab', 1, 10, 'تقرير قصير عن أصناف سلامة الليزر والأجهزة المتوفرة في المختبر.'),
 ('تقرير المختبر ٢ — معايرة المطياف', 'lab', 2, 10, 'منحنى المعايرة، قدرة التحليل، والتشتت. أرفق البيانات الخام.'),
 ('تقرير المختبر ٣ — الطيفية الذرية الانبعاثية', 'lab', 3, 10, 'تشخيص العناصر من مواقع الخطوط وشدّاتها.'),
 ('تقرير المختبر ٤ — قانون بير لامبرت', 'lab', 4, 10, 'تعيين الامتصاصية المولارية من ميل A مقابل C.'),
 ('تقرير المختبر ٥ — فجوة الطاقة ومخطط Tauc', 'lab', 5, 10, 'حساب Eg مع مناقشة نوع الانتقال.')
on conflict do nothing;
