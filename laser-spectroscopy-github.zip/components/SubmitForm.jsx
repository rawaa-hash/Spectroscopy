'use client'

import { useActionState } from 'react'
import { submitReport } from '@/app/actions'

export default function SubmitForm({ assignmentId, disabled }) {
  const [state, action, pending] = useActionState(submitReport, {})

  if (disabled) {
    return <div className="msg err">التسليم مغلق لهذا الواجب. راجعي التدريسي.</div>
  }

  return (
    <form action={action}>
      <input type="hidden" name="assignment_id" value={assignmentId} />

      {state?.error && <div className="msg err">{state.error}</div>}
      {state?.ok && <div className="msg ok">{state.ok}</div>}

      <div className="field">
        <label htmlFor="file">ملف التقرير (PDF أو Word — بحد أقصى ٢٠ ميغابايت)</label>
        <input id="file" name="file" type="file" accept=".pdf,.doc,.docx,.zip,.xlsx,.csv" required />
      </div>

      <div className="field">
        <label htmlFor="note">ملاحظة للتدريسي (اختياري)</label>
        <textarea id="note" name="note" placeholder="مثلاً: البيانات الخام مرفقة في الملحق." />
      </div>

      <button className="btn primary" disabled={pending}>
        {pending ? 'جارٍ الرفع...' : 'رفع التقرير'}
      </button>
    </form>
  )
}
