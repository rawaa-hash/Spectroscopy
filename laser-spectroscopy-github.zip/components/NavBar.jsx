'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

export default function NavBar({ name, role }) {
  const path = usePathname()
  const router = useRouter()
  const isInstructor = role === 'instructor'

  const links = [
    ['/dashboard', 'الرئيسية'],
    ['/course', 'المقرر'],
    ['/assignments', 'الواجبات'],
    ['/grades', isInstructor ? 'سجل الدرجات' : 'درجاتي'],
  ]
  if (isInstructor) links.push(['/teacher', 'إدارة الواجبات'])

  async function signOut() {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push('/login')
    router.refresh()
  }

  return (
    <nav className="nav">
      <div className="nav-in">
        <h1>
          الطيفية الليزرية
          <span>معهد الليزر للدراسات العليا — جامعة بغداد</span>
        </h1>
        <div className="who">
          <span>{name}</span>
          <span className={isInstructor ? 'badge inst' : 'badge'}>
            {isInstructor ? 'تدريسي' : 'طالب'}
          </span>
          <button className="btn ghost" style={{ padding: '5px 12px', fontSize: 13 }} onClick={signOut}>
            خروج
          </button>
        </div>
      </div>
      <div className="nav-links">
        {links.map(([href, label]) => (
          <Link key={href} href={href} className={path === href || path.startsWith(href + '/') ? 'on' : ''}>
            {label}
          </Link>
        ))}
        <a href="/tools.html" target="_blank" rel="noreferrer">أدوات حسابية ↗</a>
      </div>
    </nav>
  )
}
