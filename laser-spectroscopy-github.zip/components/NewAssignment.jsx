'use client'

import { useActionState } from 'react'
import { createAssignment } from '@/app/actions'

export default function NewAssignment() {
  const [state, action, pending] = useActionState(createAssignment, {})

  return (
    <details className="card">
      <summary style={{ cursor: 'pointer', fontWeight: 600 }}>+ إضافة واجب جديد</summary>
      <form action={action} style={{ marginTop: 14 }}>
        {state?.error && <div className="msg err">{state.error}</div>}
        {state?.ok && <div className="msg ok">{state.ok}</div>}

        <div className="field">
          <label htmlFor="title">العنوان</label>
          <input id="title" name="title" required placeholder="تقرير المختبر ٦ — FTIR" />
        </div>

        <div className="field">
          <label htmlFor="description">الوصف</label>
          <textarea id="description" name="description" placeholder="المطلوب، صيغة التقرير، البيانات المرفقة..." />
        </div>

        <div className="grid">
          <div className="field">
            <label htmlFor="kind">النوع</label>
            <select id="kind" name="kind">
              <option value="lab">تقرير مختبر</option>
              <option value="homework">واجب</option>
              <option value="project">مشروع</option>
              <option value="seminar">سمنار</option>
            </select>
          </div>
          <div className="field">
            <label htmlFor="week">الأسبوع</label>
            <input id="week" name="week" type="number" min="1" max="15" />
          </div>
          <div className="field">
            <label htmlFor="max_score">الدرجة القصوى</label>
            <input id="max_score" name="max_score" type="number" step="0.5" defaultValue="10" />
          </div>
          <div className="field">
            <label htmlFor="due_at">آخر موعد</label>
            <input id="due_at" name="due_at" type="datetime-local" />
          </div>
        </div>

        <button className="btn primary" disabled={pending}>
          {pending ? 'جارٍ الحفظ...' : 'نشر الواجب'}
        </button>
      </form>
    </details>
  )
}
