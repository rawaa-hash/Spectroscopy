'use client'

import { useActionState } from 'react'
import { gradeSubmission } from '@/app/actions'

export default function GradeForm({ submissionId, score, feedback, max }) {
  const [state, action, pending] = useActionState(gradeSubmission, {})

  return (
    <form action={action} style={{ marginTop: 12 }}>
      <input type="hidden" name="submission_id" value={submissionId} />

      {state?.error && <div className="msg err">{state.error}</div>}
      {state?.ok && <div className="msg ok">{state.ok}</div>}

      <div className="row" style={{ alignItems: 'flex-end' }}>
        <div style={{ width: 130 }}>
          <label htmlFor={`sc-${submissionId}`}>الدرجة (من {max})</label>
          <input id={`sc-${submissionId}`} name="score" type="number" step="0.5" min="0" max={max}
                 defaultValue={score ?? ''} />
        </div>
        <div style={{ flex: 1, minWidth: 200 }}>
          <label htmlFor={`fb-${submissionId}`}>ملاحظات للطالب</label>
          <input id={`fb-${submissionId}`} name="feedback" defaultValue={feedback || ''}
                 placeholder="نقاط القوة وما يحتاج تحسين" />
        </div>
        <button className="btn primary" disabled={pending}>
          {pending ? '...' : 'حفظ'}
        </button>
      </div>
    </form>
  )
}
